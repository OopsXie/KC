#!/bin/bash

# MinFS 脚本权限设置
# 用法: ./setup_permissions.sh

SCRIPT_DIR=$(dirname "$0")

echo "设置MinFS管理脚本权限..."

# 设置所有脚本为可执行
chmod +x "$SCRIPT_DIR"/*.sh

echo "权限设置完成:"
ls -la "$SCRIPT_DIR"/*.sh

echo ""
echo "新的脚本使用方法:"
echo "  启动DataServer: ./start_dataserver.sh <host> <port>"
echo "  停止DataServer: ./stop_dataserver.sh <host> <port>"
echo "  重启DataServer: ./restart_dataserver.sh <host> <port>"
echo "  状态DataServer: ./status_dataserver.sh <host> <port>"
echo ""
echo "  启动MetaServer: ./start_metaserver.sh <host> <port>"
echo "  停止MetaServer: ./stop_metaserver.sh <host> <port>"
echo "  重启MetaServer: ./restart_metaserver.sh <host> <port>"
echo "  状态MetaServer: ./status_metaserver.sh <host> <port>"
echo ""
echo "注意: 这些脚本现在基于真实的IP和端口来管理进程"
echo "后端会自动从集群信息中获取正确的IP和端口"