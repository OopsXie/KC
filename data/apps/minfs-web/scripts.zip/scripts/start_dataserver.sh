#!/bin/bash

# MinFS DataServer 启动脚本 - 基于IP和端口
# 用法: ./start_dataserver.sh <host> <port>

HOST=${1:-"localhost"}
PORT=${2:-"8001"}
DATASERVER_HOME=${DATASERVER_HOME:-"/opt/minfs/dataserver"}
LOG_DIR=${LOG_DIR:-"/var/log/minfs"}
PID_DIR=${PID_DIR:-"/var/run/minfs"}
DATA_DIR=${DATA_DIR:-"/var/lib/minfs/data"}

# 确保目录存在
mkdir -p "$LOG_DIR" "$PID_DIR" "$DATA_DIR"

# 文件路径
PID_FILE="$PID_DIR/dataserver_${HOST}_${PORT}.pid"
LOG_FILE="$LOG_DIR/dataserver_${HOST}_${PORT}.log"

echo "准备启动 DataServer ${HOST}:${PORT}..."

# 检查端口是否被占用
if lsof -ti:$PORT > /dev/null 2>&1; then
    EXISTING_PID=$(lsof -ti:$PORT | head -1)
    echo "端口 $PORT 已被进程 $EXISTING_PID 占用"
    
    # 检查是否是DataServer进程
    PROCESS_INFO=$(ps -p $EXISTING_PID -o comm=,args= 2>/dev/null)
    if [[ "$PROCESS_INFO" == *"java"* ]] && [[ "$PROCESS_INFO" == *"DataServer"* ]]; then
        echo "DataServer ${HOST}:${PORT} 已经在运行中 (PID: $EXISTING_PID)"
        echo $EXISTING_PID > "$PID_FILE"
        exit 0
    else
        echo "端口被其他进程占用: $PROCESS_INFO"
        exit 1
    fi
fi

# 检查PID文件
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if ps -p $OLD_PID > /dev/null 2>&1; then
        echo "DataServer ${HOST}:${PORT} 已经在运行中 (PID: $OLD_PID)"
        exit 0
    else
        echo "删除过期的PID文件: $PID_FILE"
        rm -f "$PID_FILE"
    fi
fi

# 检查DataServer可执行文件
DATASERVER_JAR="$DATASERVER_HOME/dataserver.jar"
if [ ! -f "$DATASERVER_JAR" ]; then
    echo "错误: 找不到DataServer JAR文件: $DATASERVER_JAR"
    echo "请设置正确的 DATASERVER_HOME 环境变量"
    exit 1
fi

# 构建启动命令
JAVA_OPTS=${JAVA_OPTS:-"-Xmx1g -Xms512m"}
START_CMD="java $JAVA_OPTS -jar $DATASERVER_JAR --host=$HOST --port=$PORT --data-dir=$DATA_DIR"

echo "启动命令: $START_CMD"
echo "日志文件: $LOG_FILE"

# 启动DataServer
nohup $START_CMD > "$LOG_FILE" 2>&1 &
NEW_PID=$!

# 保存PID
echo $NEW_PID > "$PID_FILE"

# 等待启动
echo "等待DataServer启动..."
WAIT_TIME=0
MAX_WAIT=30

while [ $WAIT_TIME -lt $MAX_WAIT ]; do
    if ! ps -p $NEW_PID > /dev/null 2>&1; then
        echo "DataServer启动失败，进程已退出"
        echo "请检查日志文件: $LOG_FILE"
        rm -f "$PID_FILE"
        exit 1
    fi
    
    # 检查端口是否开始监听
    if lsof -ti:$PORT > /dev/null 2>&1; then
        echo "DataServer ${HOST}:${PORT} 启动成功 (PID: $NEW_PID)"
        echo "日志文件: $LOG_FILE"
        exit 0
    fi
    
    sleep 1
    WAIT_TIME=$((WAIT_TIME + 1))
    echo "等待端口 $PORT 开始监听... ($WAIT_TIME/$MAX_WAIT)"
done

echo "启动超时，DataServer可能启动失败"
echo "请检查日志文件: $LOG_FILE"

# 检查进程是否还在运行
if ps -p $NEW_PID > /dev/null 2>&1; then
    echo "进程仍在运行，但端口未开始监听"
    exit 1
else
    echo "进程已退出"
    rm -f "$PID_FILE"
    exit 1
fi