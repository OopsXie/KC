#!/bin/bash

# MinFS DataServer 状态检查脚本 - 基于IP和端口
# 用法: ./status_dataserver.sh <host> <port>

HOST=${1:-"localhost"}
PORT=${2:-"8001"}
PID_DIR=${PID_DIR:-"/var/run/minfs"}

PID_FILE="$PID_DIR/dataserver_${HOST}_${PORT}.pid"

echo "检查 DataServer ${HOST}:${PORT} 状态..."

# 检查PID文件
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p $PID > /dev/null 2>&1; then
        PROCESS_INFO=$(ps -p $PID -o pid,ppid,etime,comm,args --no-headers)
        echo "DataServer 正在运行:"
        echo "  PID: $PID"
        echo "  进程信息: $PROCESS_INFO"
        
        # 检查端口监听状态
        if lsof -ti:$PORT > /dev/null 2>&1; then
            echo "  端口状态: $PORT 正在监听"
        else
            echo "  端口状态: $PORT 未监听 (可能正在启动)"
        fi
        
        # 检查进程资源使用
        if command -v top > /dev/null 2>&1; then
            CPU_MEM=$(top -p $PID -b -n 1 | tail -1 | awk '{print "CPU:"$9"% MEM:"$10"%"}')
            echo "  资源使用: $CPU_MEM"
        fi
        
        exit 0
    else
        echo "PID文件存在但进程不存在，清理PID文件"
        rm -f "$PID_FILE"
    fi
fi

# 通过端口查找进程
PORT_PID=$(lsof -ti:$PORT 2>/dev/null | head -1)
if [ -n "$PORT_PID" ]; then
    PROCESS_INFO=$(ps -p $PORT_PID -o pid,ppid,etime,comm,args --no-headers 2>/dev/null)
    echo "发现端口 $PORT 被占用:"
    echo "  PID: $PORT_PID"
    echo "  进程信息: $PROCESS_INFO"
    
    # 检查是否是Java进程
    if [[ "$PROCESS_INFO" == *"java"* ]]; then
        echo "  可能是 DataServer 进程 (建议更新PID文件)"
        echo $PORT_PID > "$PID_FILE"
    else
        echo "  非Java进程占用端口"
    fi
    exit 0
fi

# 通过进程名查找
JAVA_PID=$(pgrep -f "java.*DataServer.*$PORT" | head -1)
if [ -n "$JAVA_PID" ]; then
    PROCESS_INFO=$(ps -p $JAVA_PID -o pid,ppid,etime,comm,args --no-headers 2>/dev/null)
    echo "通过进程名找到可能的DataServer:"
    echo "  PID: $JAVA_PID"
    echo "  进程信息: $PROCESS_INFO"
    echo "  建议更新PID文件"
    echo $JAVA_PID > "$PID_FILE"
    exit 0
fi

echo "DataServer ${HOST}:${PORT} 未运行"
exit 1