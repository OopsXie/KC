#!/bin/bash

# MinFS DataServer 重启脚本 - 基于IP和端口
# 用法: ./restart_dataserver.sh <host> <port>

HOST=${1:-"localhost"}
PORT=${2:-"8001"}

SCRIPT_DIR=$(dirname "$0")

echo "重启 DataServer ${HOST}:${PORT}..."

# 先停止
echo "步骤1: 停止DataServer"
bash "$SCRIPT_DIR/stop_dataserver.sh" "$HOST" "$PORT"
STOP_RESULT=$?

# 等待一下确保完全停止
sleep 2

# 再启动
echo "步骤2: 启动DataServer"
bash "$SCRIPT_DIR/start_dataserver.sh" "$HOST" "$PORT"
START_RESULT=$?

if [ $START_RESULT -eq 0 ]; then
    echo "DataServer ${HOST}:${PORT} 重启成功"
else
    echo "DataServer ${HOST}:${PORT} 重启失败"
fi

exit $START_RESULT