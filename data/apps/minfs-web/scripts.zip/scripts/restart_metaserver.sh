#!/bin/bash

# MinFS MetaServer 重启脚本 - 基于IP和端口
# 用法: ./restart_metaserver.sh <host> <port>

HOST=${1:-"localhost"}
PORT=${2:-"9090"}

SCRIPT_DIR=$(dirname "$0")

echo "重启 MetaServer ${HOST}:${PORT}..."

# 先停止
echo "步骤1: 停止MetaServer"
bash "$SCRIPT_DIR/stop_metaserver.sh" "$HOST" "$PORT"
STOP_RESULT=$?

# 等待一下确保完全停止
sleep 2

# 再启动
echo "步骤2: 启动MetaServer"
bash "$SCRIPT_DIR/start_metaserver.sh" "$HOST" "$PORT"
START_RESULT=$?

if [ $START_RESULT -eq 0 ]; then
    echo "MetaServer ${HOST}:${PORT} 重启成功"
else
    echo "MetaServer ${HOST}:${PORT} 重启失败"
fi

exit $START_RESULT