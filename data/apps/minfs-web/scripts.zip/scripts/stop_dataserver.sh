#!/bin/bash

# MinFS DataServer 停止脚本 - 基于IP和端口
# 用法: ./stop_dataserver.sh <host> <port>

HOST=${1:-"localhost"}
PORT=${2:-"8001"}
PID_DIR=${PID_DIR:-"/var/run/minfs"}

# 确保PID目录存在
mkdir -p "$PID_DIR"

echo "正在停止 DataServer ${HOST}:${PORT}..."

# 方法1: 通过PID文件查找
PID_FILE="$PID_DIR/dataserver_${HOST}_${PORT}.pid"
FOUND_PID=""

if [ -f "$PID_FILE" ]; then
    FOUND_PID=$(cat "$PID_FILE")
    if ps -p $FOUND_PID > /dev/null 2>&1; then
        echo "通过PID文件找到进程: $FOUND_PID"
    else
        echo "PID文件中的进程已不存在，清理PID文件"
        rm -f "$PID_FILE"
        FOUND_PID=""
    fi
fi

# 方法2: 如果PID文件不存在，通过端口查找进程
if [ -z "$FOUND_PID" ]; then
    echo "通过端口 $PORT 查找进程..."
    # 查找监听指定端口的进程
    FOUND_PID=$(lsof -ti:$PORT 2>/dev/null | head -1)
    
    if [ -n "$FOUND_PID" ]; then
        echo "通过端口找到进程: $FOUND_PID"
        # 验证这是否是Java进程（可能是MinFS DataServer）
        PROCESS_INFO=$(ps -p $FOUND_PID -o comm= 2>/dev/null)
        if [[ "$PROCESS_INFO" == *"java"* ]]; then
            echo "确认为Java进程，可能是DataServer"
        else
            echo "警告: 端口 $PORT 被非Java进程占用: $PROCESS_INFO"
        fi
    fi
fi

# 方法3: 通过进程命令行查找
if [ -z "$FOUND_PID" ]; then
    echo "通过进程命令行查找DataServer..."
    # 查找包含DataServer和端口信息的Java进程
    FOUND_PID=$(pgrep -f "java.*DataServer.*$PORT" | head -1)
    if [ -n "$FOUND_PID" ]; then
        echo "通过命令行找到DataServer进程: $FOUND_PID"
    fi
fi

if [ -z "$FOUND_PID" ]; then
    echo "未找到运行在 ${HOST}:${PORT} 的DataServer进程"
    exit 0
fi

echo "准备停止进程 $FOUND_PID..."

# 首先尝试优雅停止 (SIGTERM)
kill -TERM $FOUND_PID 2>/dev/null

# 等待进程优雅退出
WAIT_TIME=0
MAX_WAIT=30

while [ $WAIT_TIME -lt $MAX_WAIT ]; do
    if ! ps -p $FOUND_PID > /dev/null 2>&1; then
        echo "DataServer ${HOST}:${PORT} 已成功停止"
        rm -f "$PID_FILE"
        exit 0
    fi
    sleep 1
    WAIT_TIME=$((WAIT_TIME + 1))
    echo "等待进程退出... ($WAIT_TIME/$MAX_WAIT)"
done

# 如果优雅停止失败，强制终止
echo "优雅停止超时，强制终止进程..."
kill -KILL $FOUND_PID 2>/dev/null

# 再次检查
sleep 2
if ! ps -p $FOUND_PID > /dev/null 2>&1; then
    echo "DataServer ${HOST}:${PORT} 已强制停止"
    rm -f "$PID_FILE"
    exit 0
else
    echo "错误: 无法停止DataServer进程 $FOUND_PID"
    exit 1
fi